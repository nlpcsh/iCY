module.exports = {
  connectionString: './data/db.json',
  port: 9001
};