'use strict';

let express = require('express');

module.exports = function(app, data) {
  let router = new express.Router();

  router.get('/', function(req, res) {
      res.send({
        result: data.challenges.all()
      });
    })
    .post('/', function(req, res) {
      res.send({
        result: data.challenges.save(req.body)
      });
    });

  app.use('/api/challenges', router);
};